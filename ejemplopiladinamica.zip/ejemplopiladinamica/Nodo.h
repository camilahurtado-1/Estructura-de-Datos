
#pragma once
#include <string>

using namespace std;

class Nodo
{
	public:
		string nombre, dato;
		Nodo* sig;
	};

